import logging
import os
import time
import colorlog
# 设置相对路径
ProjectPath = os.path.split(os.path.split(os.path.realpath(__file__))[0])[0]
LogsPath = os.path.join(ProjectPath, 'logs{0}'.format(time.strftime('%Y-%m-%d_%H-%M-%S',time.localtime())))

# 设置控制台打印的颜色
log_colors_config = {
    'DEBUG': 'cyan',
    'INFO': 'black',
    'WARNING': 'yellow',
    'ERROR': 'red',
    'CRITICAL': 'red',
}

class MyLogs:
    def mylog(self, level, msg):
        logger = logging.getLogger('')
        logger.setLevel(logging.DEBUG)
        formatter = colorlog.ColoredFormatter(
            '%(log_color)s[%(asctime)s] [%(name)s] [%(levelname)s]: %(message)s',
            log_colors=log_colors_config)
        formatter2 = logging.Formatter('[%(asctime)s] [%(name)s] [%(levelname)s]: %(message)s')
        sh = logging.StreamHandler()  # 输出到控制台
        sh.setLevel(logging.DEBUG)
        sh.setFormatter(formatter)  # 指定格式

        fh = logging.FileHandler(LogsPath, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(formatter2)
        logger.addHandler(sh)
        logger.addHandler(fh)  # 输出到文件

        if level == "DEBUG":
            logger.debug(msg)
        elif level == "INFO":
            logger.info(msg)
        elif level == "WARNING":
            logger.warning(msg)
        elif level == "ERROR":
            logger.error(msg)
        elif level == "CRITICAL":
            logger.critical(msg)
        logger.removeHandler(sh)
        logger.removeHandler(fh)
        fh.close() #不关闭会警告

    def debug(self, msg):
        self.mylog("DEBUG", msg)

    def info(self, msg):
        self.mylog("INFO", msg)

    def warning(self, msg):
        self.mylog("WARNING", msg)

    def error(self, msg):
        self.mylog("ERROR", msg)

    def critical(self, msg):
        self.mylog("CRITICAL", msg)

    def logsath(self):
        print("日志文件存放路径为:" + LogsPath)


